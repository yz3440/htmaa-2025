"""pano2points - Convert equirectangular panoramas to point clouds for laser engraving."""

__version__ = "0.1.0"
